

$start_time = microtime(true);

$end_time = microtime(true);

$time = $end_time - $start_time;


$response = "Command processed in $time seconds.";

}
